INSERT INTO ruoyi_race.sys_user_role (user_id,role_id) VALUES
	 (1,1),
	 (101,101),
	 (103,104),
	 (104,103),
	 (105,2),
	 (106,103),
	 (109,103),
	 (110,103),
	 (111,103),
	 (112,103);
INSERT INTO ruoyi_race.sys_user_role (user_id,role_id) VALUES
	 (113,103),
	 (114,103),
	 (115,103),
	 (116,103),
	 (117,103),
	 (118,103),
	 (119,103),
	 (120,103),
	 (121,103),
	 (122,103);
INSERT INTO ruoyi_race.sys_user_role (user_id,role_id) VALUES
	 (123,103),
	 (124,103),
	 (125,103),
	 (126,103),
	 (127,103),
	 (128,103),
	 (129,103),
	 (130,103),
	 (131,103),
	 (132,102);
INSERT INTO ruoyi_race.sys_user_role (user_id,role_id) VALUES
	 (133,103),
	 (134,103),
	 (135,103),
	 (136,103),
	 (137,103),
	 (138,103),
	 (139,103),
	 (140,103),
	 (141,103),
	 (142,103);
INSERT INTO ruoyi_race.sys_user_role (user_id,role_id) VALUES
	 (143,103),
	 (144,103),
	 (145,103),
	 (146,103),
	 (147,103),
	 (148,103),
	 (149,103),
	 (150,103),
	 (151,103),
	 (152,103);
INSERT INTO ruoyi_race.sys_user_role (user_id,role_id) VALUES
	 (153,103),
	 (154,103),
	 (155,103),
	 (156,103),
	 (157,103),
	 (158,103),
	 (159,103),
	 (160,103),
	 (161,103),
	 (162,103);
INSERT INTO ruoyi_race.sys_user_role (user_id,role_id) VALUES
	 (163,103),
	 (164,103),
	 (165,103),
	 (166,103);
