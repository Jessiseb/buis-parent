INSERT INTO ruoyi_race.sys_role (role_name,role_key,role_sort,data_scope,menu_check_strictly,dept_check_strictly,status,del_flag,create_by,create_time,update_by,update_time,remark) VALUES
	 ('超级管理员','admin',1,'1',1,1,'0','0','admin','2024-10-09 04:31:58','',NULL,'超级管理员'),
	 ('普通角色','common',2,'2',1,1,'0','0','admin','2024-10-09 04:31:58','admin','2025-06-10 12:38:43','普通角色'),
	 ('学生助理','assistant',3,'1',1,1,'0','0','admin','2024-12-02 10:52:54','admin','2025-05-12 14:15:58',NULL),
	 ('评委','judge',4,'1',1,1,'0','0','admin','2024-12-02 11:20:02','admin','2025-05-14 10:35:23',NULL),
	 ('教师','teacher',5,'1',1,1,'0','0','admin','2024-12-02 11:26:20','admin','2025-03-31 10:18:50',NULL),
	 ('院级角色','institute',6,'1',1,1,'0','0','admin','2024-12-06 00:35:12','admin','2024-12-06 00:38:26',''),
	 ('校级角色','school',7,'1',1,1,'0','0','admin','2024-12-06 00:43:55','',NULL,NULL),
	 ('班级成员','admin11',2,'2',1,1,'0','2','admin','2024-12-20 12:50:22','admin','2024-12-20 12:50:35',NULL),
	 ('test','2',0,'1',1,1,'0','2','admin','2025-06-04 02:57:25','admin','2025-06-04 02:58:35',NULL);
