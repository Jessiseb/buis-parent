INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：32368毫秒','0','','2025-03-18 10:08:50'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：1761毫秒','0','','2025-03-18 10:42:09'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：1160毫秒','0','','2025-03-18 10:46:10'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：62481毫秒','0','','2025-03-18 10:48:52'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：38670毫秒','0','','2025-03-18 13:46:50'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：41854毫秒','0','','2025-03-18 13:51:37'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：47055毫秒','0','','2025-03-18 13:58:34'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：21毫秒','1','java.lang.reflect.InvocationTargetException
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:77)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:568)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.RuntimeException: 条件检测异常
	at com.buis.service.impl.TeamInfoServiceImpl.hasSearchCondition(TeamInfoServiceImpl.java:438)
	at com.buis.service.impl.TeamInfoServiceImpl.selectTeamInfoList(TeamInfoServiceImpl.java:375)
	at com.buis.service.impl.TeamInfoServiceImpl$$FastClassBySpringCGLIB$$b158e959.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.TeamInfoServiceImpl$$EnhancerBySpringCGLIB$$a9d8eb7e.selectTeamInfoList(<generated>)
	at com.buis.quartz.task.TeamTask.warmUp(TeamTask.java:37)
	... 10 more
Caused by: java.lang.NoSuchFieldException: collage
	at java.base/java.lang.Class.getDeclaredField(Class.java:2610)
	at com.buis.service.impl.TeamInfoServiceImpl.hasSearchCondition(TeamInfoServiceImpl.java:430)
	.','2025-03-18 16:31:18'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：94866毫秒','1','java.lang.reflect.InvocationTargetException
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:77)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:568)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.RuntimeException: 条件检测异常
	at com.buis.service.impl.TeamInfoServiceImpl.hasSearchCondition(TeamInfoServiceImpl.java:438)
	at com.buis.service.impl.TeamInfoServiceImpl.selectTeamInfoList(TeamInfoServiceImpl.java:375)
	at com.buis.service.impl.TeamInfoServiceImpl$$FastClassBySpringCGLIB$$b158e959.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.TeamInfoServiceImpl$$EnhancerBySpringCGLIB$$a9d8eb7e.selectTeamInfoList(<generated>)
	at com.buis.quartz.task.TeamTask.warmUp(TeamTask.java:37)
	... 10 more
Caused by: java.lang.NoSuchFieldException: collage
	at java.base/java.lang.Class.getDeclaredField(Class.java:2610)
	at com.buis.service.impl.TeamInfoServiceImpl.hasSearchCondition(TeamInfoServiceImpl.java:430)
	.','2025-03-18 16:33:58'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：7毫秒','1','java.lang.reflect.InvocationTargetException
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:77)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:568)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException: Cannot invoke "org.springframework.web.context.request.ServletRequestAttributes.getRequest()" because the return value of "com.buis.common.utils.ServletUtils.getRequestAttributes()" is null
	at com.buis.common.utils.ServletUtils.getRequest(ServletUtils.java:108)
	at com.buis.common.utils.ServletUtils.getParameter(ServletUtils.java:32)
	at com.buis.common.core.page.TableSupport.getPageDomain(TableSupport.java:44)
	at com.buis.common.core.page.TableSupport.buildPageRequest(TableSupport.java:54)
	at com.buis.service.impl.TeamInfoServiceImpl.selectTeamInfoList(TeamInfoServiceImpl.java:399)
	at com.buis.service.impl.TeamInfoServiceImpl$$FastClassBySpringCGLIB$$b158e959.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)','2025-03-19 03:13:31');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：39307毫秒','0','','2025-03-19 03:29:46'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：32999毫秒','0','','2025-03-19 03:59:45'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：75676毫秒','1','java.lang.reflect.InvocationTargetException
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:77)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:568)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException: Cannot invoke "com.github.pagehelper.Page.getTotal()" because "com.buis.common.utils.PageUtils.page" is null
	at com.buis.common.core.page.MyPageVo.<init>(MyPageVo.java:47)
	at com.buis.quartz.task.TeamTask.warmUp(TeamTask.java:51)
	... 10 more
','2025-03-19 04:10:48'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：19295毫秒','1','java.lang.reflect.InvocationTargetException
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:77)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:568)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException: Cannot invoke "com.github.pagehelper.Page.getTotal()" because "com.buis.common.utils.PageUtils.page" is null
	at com.buis.common.core.page.MyPageVo.<init>(MyPageVo.java:47)
	at com.buis.quartz.task.TeamTask.warmUp(TeamTask.java:52)
	... 10 more
','2025-03-19 04:13:35'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：41974毫秒','1','java.lang.reflect.InvocationTargetException
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:77)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:568)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException: Cannot invoke "com.github.pagehelper.Page.getTotal()" because "com.buis.common.utils.PageUtils.page" is null
	at com.buis.common.core.page.MyPageVo.<init>(MyPageVo.java:47)
	at com.buis.quartz.task.TeamTask.warmUp(TeamTask.java:52)
	... 10 more
','2025-03-19 04:18:49'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：881毫秒','0','','2025-03-19 04:20:55'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：53425毫秒','0','','2025-03-19 04:27:16'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：41153毫秒','0','','2025-03-19 04:58:22'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：39948毫秒','0','','2025-03-19 09:57:04'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：32091毫秒','0','','2025-03-20 06:51:16');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：35822毫秒','0','','2025-03-20 06:52:29'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：415毫秒','0','','2025-03-26 02:53:36'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：210毫秒','0','','2025-03-26 03:45:08'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：188毫秒','0','','2025-03-26 03:57:11'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：89683毫秒','0','','2025-03-26 14:54:16'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：691毫秒','0','','2025-03-26 14:57:10'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：222毫秒','0','','2025-03-26 14:57:59'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：12491毫秒','0','','2025-03-26 15:00:55'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：4248毫秒','0','','2025-03-29 16:00:04'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：117毫秒','0','','2025-03-29 18:00:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：340毫秒','0','','2025-03-29 18:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：4151毫秒','0','','2025-03-30 16:00:04'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：197毫秒','0','','2025-03-30 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：412毫秒','0','','2025-03-30 18:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：4376毫秒','0','','2025-03-31 16:00:04'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：10130毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: org.springframework.dao.QueryTimeoutException: Redis command timed out; nested exception is io.lettuce.core.RedisCommandTimeoutException: Command timed out after 10 second(s)
	at org.springframework.data.redis.connection.lettuce.LettuceExceptionConverter.convert(LettuceExceptionConverter.java:70)
	at org.springframework.data.redis.connection.lettuce.LettuceExceptionConverter.convert(LettuceExceptionConverter.java:41)
	at org.springframework.data.redis.PassThroughExceptionTranslationStrategy.translate(PassThroughExceptionTranslationStrategy.java:44)
	at org.springframework.data.redis.FallbackExceptionTranslationStrategy.translate(FallbackExceptionTranslationStrategy.java:42)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.convertLettuceAccessException(LettuceConnection.java:271)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.await(LettuceConnection.java:1062)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.lambda$doInvoke$4(LettuceConnection.java:919)
	at org.springframework.data.redis.connection.lettuce.LettuceInvoker$Synchronizer.invoke(LettuceInvoker.java:665)
	at ','2025-03-31 16:00:11'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：128毫秒','0','','2025-03-31 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：398毫秒','0','','2025-03-31 18:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：4169毫秒','0','','2025-04-01 16:00:04'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：130毫秒','0','','2025-04-01 18:00:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：355毫秒','0','','2025-04-01 18:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：4183毫秒','0','','2025-04-02 16:00:04'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：110毫秒','0','','2025-04-02 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：140毫秒','0','','2025-04-02 18:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：4328毫秒','0','','2025-04-03 16:00:04'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：85毫秒','0','','2025-04-03 18:00:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：99毫秒','0','','2025-04-03 18:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：4527毫秒','0','','2025-04-04 16:00:04'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：10180毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: org.springframework.dao.QueryTimeoutException: Redis command timed out; nested exception is io.lettuce.core.RedisCommandTimeoutException: Command timed out after 10 second(s)
	at org.springframework.data.redis.connection.lettuce.LettuceExceptionConverter.convert(LettuceExceptionConverter.java:70)
	at org.springframework.data.redis.connection.lettuce.LettuceExceptionConverter.convert(LettuceExceptionConverter.java:41)
	at org.springframework.data.redis.PassThroughExceptionTranslationStrategy.translate(PassThroughExceptionTranslationStrategy.java:44)
	at org.springframework.data.redis.FallbackExceptionTranslationStrategy.translate(FallbackExceptionTranslationStrategy.java:42)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.convertLettuceAccessException(LettuceConnection.java:271)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.await(LettuceConnection.java:1062)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.lambda$doInvoke$4(LettuceConnection.java:919)
	at org.springframework.data.redis.connection.lettuce.LettuceInvoker$Synchronizer.invoke(LettuceInvoker.java:665)
	at ','2025-04-04 16:59:47'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：81毫秒','0','','2025-04-04 18:00:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：302毫秒','0','','2025-04-04 18:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：6202毫秒','0','','2025-04-05 16:00:06'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：111毫秒','0','','2025-04-05 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：262毫秒','0','','2025-04-05 18:00:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：168毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: org.springframework.data.redis.RedisSystemException: Redis exception; nested exception is io.lettuce.core.RedisException: java.io.IOException: 远程主机强迫关闭了一个现有的连接。
	at org.springframework.data.redis.connection.lettuce.LettuceExceptionConverter.convert(LettuceExceptionConverter.java:74)
	at org.springframework.data.redis.connection.lettuce.LettuceExceptionConverter.convert(LettuceExceptionConverter.java:41)
	at org.springframework.data.redis.PassThroughExceptionTranslationStrategy.translate(PassThroughExceptionTranslationStrategy.java:44)
	at org.springframework.data.redis.FallbackExceptionTranslationStrategy.translate(FallbackExceptionTranslationStrategy.java:42)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.convertLettuceAccessException(LettuceConnection.java:271)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.await(LettuceConnection.java:1062)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.lambda$doInvoke$4(LettuceConnection.java:919)
	at org.springframework.data.redis.connection.lettuce.LettuceInvoker$Synchronizer.invoke(LettuceInvoker.java:673)
	at org.springfram','2025-04-05 18:00:02'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：3240毫秒','0','','2025-04-05 18:00:04'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：10051毫秒','1','java.lang.reflect.InvocationTargetException
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:77)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:568)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: org.springframework.dao.QueryTimeoutException: Redis command timed out; nested exception is io.lettuce.core.RedisCommandTimeoutException: Command timed out after 10 second(s)
	at org.springframework.data.redis.connection.lettuce.LettuceExceptionConverter.convert(LettuceExceptionConverter.java:70)
	at org.springframework.data.redis.connection.lettuce.LettuceExceptionConverter.convert(LettuceExceptionConverter.java:41)
	at org.springframework.data.redis.PassThroughExceptionTranslationStrategy.translate(PassThroughExceptionTranslationStrategy.java:44)
	at org.springframework.data.redis.FallbackExceptionTranslationStrategy.translate(FallbackExceptionTranslationStrategy.java:42)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.convertLettuceAccessException(LettuceConnection.java:271)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.await(LettuceConnection.java:1062)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.lambda$doInvoke$4(LettuceConnection.java:919)
	at org.springframework.data.redis.connection.lettuc','2025-04-05 18:00:09'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：10051毫秒','1','java.lang.reflect.InvocationTargetException
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:77)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:568)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: org.springframework.dao.QueryTimeoutException: Redis command timed out; nested exception is io.lettuce.core.RedisCommandTimeoutException: Command timed out after 10 second(s)
	at org.springframework.data.redis.connection.lettuce.LettuceExceptionConverter.convert(LettuceExceptionConverter.java:70)
	at org.springframework.data.redis.connection.lettuce.LettuceExceptionConverter.convert(LettuceExceptionConverter.java:41)
	at org.springframework.data.redis.PassThroughExceptionTranslationStrategy.translate(PassThroughExceptionTranslationStrategy.java:44)
	at org.springframework.data.redis.FallbackExceptionTranslationStrategy.translate(FallbackExceptionTranslationStrategy.java:42)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.convertLettuceAccessException(LettuceConnection.java:271)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.await(LettuceConnection.java:1062)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.lambda$doInvoke$4(LettuceConnection.java:919)
	at org.springframework.data.redis.connection.lettuc','2025-04-05 18:00:09'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：5312毫秒','0','','2025-04-06 16:00:05'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：10030毫秒','1','java.lang.reflect.InvocationTargetException
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:77)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:568)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: org.springframework.dao.QueryTimeoutException: Redis command timed out; nested exception is io.lettuce.core.RedisCommandTimeoutException: Command timed out after 10 second(s)
	at org.springframework.data.redis.connection.lettuce.LettuceExceptionConverter.convert(LettuceExceptionConverter.java:70)
	at org.springframework.data.redis.connection.lettuce.LettuceExceptionConverter.convert(LettuceExceptionConverter.java:41)
	at org.springframework.data.redis.PassThroughExceptionTranslationStrategy.translate(PassThroughExceptionTranslationStrategy.java:44)
	at org.springframework.data.redis.FallbackExceptionTranslationStrategy.translate(FallbackExceptionTranslationStrategy.java:42)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.convertLettuceAccessException(LettuceConnection.java:271)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.await(LettuceConnection.java:1062)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.lambda$doInvoke$4(LettuceConnection.java:919)
	at org.springframework.data.redis.connection.lettuc','2025-04-06 16:38:55');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：182毫秒','0','','2025-04-06 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：416毫秒','0','','2025-04-06 18:00:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：10007毫秒','1','java.lang.reflect.InvocationTargetException
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:77)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:568)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: org.springframework.dao.QueryTimeoutException: Redis command timed out; nested exception is io.lettuce.core.RedisCommandTimeoutException: Command timed out after 10 second(s)
	at org.springframework.data.redis.connection.lettuce.LettuceExceptionConverter.convert(LettuceExceptionConverter.java:70)
	at org.springframework.data.redis.connection.lettuce.LettuceExceptionConverter.convert(LettuceExceptionConverter.java:41)
	at org.springframework.data.redis.PassThroughExceptionTranslationStrategy.translate(PassThroughExceptionTranslationStrategy.java:44)
	at org.springframework.data.redis.FallbackExceptionTranslationStrategy.translate(FallbackExceptionTranslationStrategy.java:42)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.convertLettuceAccessException(LettuceConnection.java:271)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.await(LettuceConnection.java:1062)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.lambda$doInvoke$4(LettuceConnection.java:919)
	at org.springframework.data.redis.connection.lettuc','2025-04-06 18:00:10'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：10006毫秒','1','java.lang.reflect.InvocationTargetException
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:77)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:568)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: org.springframework.dao.QueryTimeoutException: Redis command timed out; nested exception is io.lettuce.core.RedisCommandTimeoutException: Command timed out after 10 second(s)
	at org.springframework.data.redis.connection.lettuce.LettuceExceptionConverter.convert(LettuceExceptionConverter.java:70)
	at org.springframework.data.redis.connection.lettuce.LettuceExceptionConverter.convert(LettuceExceptionConverter.java:41)
	at org.springframework.data.redis.PassThroughExceptionTranslationStrategy.translate(PassThroughExceptionTranslationStrategy.java:44)
	at org.springframework.data.redis.FallbackExceptionTranslationStrategy.translate(FallbackExceptionTranslationStrategy.java:42)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.convertLettuceAccessException(LettuceConnection.java:271)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.await(LettuceConnection.java:1062)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.lambda$doInvoke$4(LettuceConnection.java:919)
	at org.springframework.data.redis.connection.lettuc','2025-04-06 18:00:10'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：4408毫秒','0','','2025-04-07 16:00:04'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：10158毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: org.springframework.dao.QueryTimeoutException: Redis command timed out; nested exception is io.lettuce.core.RedisCommandTimeoutException: Command timed out after 10 second(s)
	at org.springframework.data.redis.connection.lettuce.LettuceExceptionConverter.convert(LettuceExceptionConverter.java:70)
	at org.springframework.data.redis.connection.lettuce.LettuceExceptionConverter.convert(LettuceExceptionConverter.java:41)
	at org.springframework.data.redis.PassThroughExceptionTranslationStrategy.translate(PassThroughExceptionTranslationStrategy.java:44)
	at org.springframework.data.redis.FallbackExceptionTranslationStrategy.translate(FallbackExceptionTranslationStrategy.java:42)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.convertLettuceAccessException(LettuceConnection.java:271)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.await(LettuceConnection.java:1062)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.lambda$doInvoke$4(LettuceConnection.java:919)
	at org.springframework.data.redis.connection.lettuce.LettuceInvoker$Synchronizer.invoke(LettuceInvoker.java:665)
	at ','2025-04-07 16:00:10'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：87毫秒','0','','2025-04-07 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：199毫秒','0','','2025-04-07 18:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：4865毫秒','0','','2025-04-08 16:00:04'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：100毫秒','0','','2025-04-08 18:00:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：248毫秒','0','','2025-04-08 18:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：6118毫秒','0','','2025-04-09 16:00:06'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：179毫秒','0','','2025-04-09 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：441毫秒','0','','2025-04-09 18:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：4160毫秒','0','','2025-04-10 16:00:04'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：67毫秒','0','','2025-04-10 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：166毫秒','0','','2025-04-10 18:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：4364毫秒','0','','2025-04-11 16:00:04'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：130毫秒','0','','2025-04-11 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：177毫秒','0','','2025-04-11 18:00:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：4290毫秒','0','','2025-04-12 16:00:04'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：113毫秒','0','','2025-04-12 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：117毫秒','0','','2025-04-12 18:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：6574毫秒','0','','2025-04-13 16:00:06'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：429毫秒','0','','2025-04-13 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：786毫秒','0','','2025-04-13 18:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：5844毫秒','0','','2025-04-14 16:00:06'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：239毫秒','0','','2025-04-14 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：505毫秒','0','','2025-04-14 18:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：6545毫秒','0','','2025-04-15 16:00:06');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：49290毫秒','0','','2025-04-15 16:00:48'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：405毫秒','0','','2025-04-15 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：818毫秒','0','','2025-04-15 18:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：4300毫秒','0','','2025-04-16 16:00:04'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：10014毫秒','1','java.lang.reflect.InvocationTargetException
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:77)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:568)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: org.springframework.dao.QueryTimeoutException: Redis command timed out; nested exception is io.lettuce.core.RedisCommandTimeoutException: Command timed out after 10 second(s)
	at org.springframework.data.redis.connection.lettuce.LettuceExceptionConverter.convert(LettuceExceptionConverter.java:70)
	at org.springframework.data.redis.connection.lettuce.LettuceExceptionConverter.convert(LettuceExceptionConverter.java:41)
	at org.springframework.data.redis.PassThroughExceptionTranslationStrategy.translate(PassThroughExceptionTranslationStrategy.java:44)
	at org.springframework.data.redis.FallbackExceptionTranslationStrategy.translate(FallbackExceptionTranslationStrategy.java:42)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.convertLettuceAccessException(LettuceConnection.java:271)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.await(LettuceConnection.java:1062)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.lambda$doInvoke$4(LettuceConnection.java:919)
	at org.springframework.data.redis.connection.lettuc','2025-04-16 16:01:13'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：109790毫秒','0','','2025-04-16 16:01:49'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：519毫秒','0','','2025-04-16 18:00:01'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：1419毫秒','0','','2025-04-16 18:00:01'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：4181毫秒','0','','2025-04-17 16:00:04'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：194毫秒','0','','2025-04-17 18:00:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：259毫秒','0','','2025-04-17 18:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：7753毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 10
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1148)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$84f870e.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-04-18 16:00:07'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：90毫秒','0','','2025-04-18 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：215毫秒','0','','2025-04-18 18:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：6153毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 2
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1148)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$ba073011.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-04-19 16:00:06'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：160毫秒','0','','2025-04-19 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：239毫秒','0','','2025-04-19 18:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：8613毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 10
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1148)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$ba073011.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-04-20 16:00:08'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：91毫秒','0','','2025-04-20 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：579毫秒','0','','2025-04-20 18:00:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：8090毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 10
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1148)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$8b123126.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-04-21 16:00:08'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：125毫秒','0','','2025-04-21 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：332毫秒','0','','2025-04-21 18:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：8154毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 11
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1175)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$d77dd66f.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-04-22 16:00:08'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：87毫秒','0','','2025-04-22 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：168毫秒','0','','2025-04-22 18:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：9594毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 11
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1188)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$5177ccf2.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-04-23 16:00:09'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：241毫秒','0','','2025-04-23 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：720毫秒','0','','2025-04-23 18:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：9426毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 11
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1188)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$16f379f8.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-04-24 16:00:09');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：40782毫秒','1','java.lang.reflect.InvocationTargetException
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:77)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:568)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: 
### Error querying database.  Cause: com.mysql.cj.jdbc.exceptions.CommunicationsException: Communications link failure

The last packet successfully received from the server was 1,063 milliseconds ago. The last packet sent successfully to the server was 1,074 milliseconds ago.
### The error may exist in file [D:\\workspaces\\Innovation-entrepreneurship-platform-backend\\buis-parent\\buis-system\\target\\classes\\mapper\\system\\SysDictDataMapper.xml]
### The error may involve defaultParameterMap
### The error occurred while setting parameters
### SQL: select dict_label from sys_dict_data   where dict_type = ? and dict_value = ?
### Cause: com.mysql.cj.jdbc.exceptions.CommunicationsException: Communications link failure

The last packet successfully received from the server was 1,063 milliseconds ago. The last packet sent successfully to the server was 1,074 milliseconds ago.
; Communications link failure

The last packet successfully received from the server was 1,063 milliseconds ago. The last packet sent successfully to the server w','2025-04-24 16:00:39'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：158毫秒','0','','2025-04-24 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：476毫秒','0','','2025-04-24 18:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：23814毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 11
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1188)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$38609580.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-04-25 16:00:24'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：412毫秒','0','','2025-04-25 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：1111毫秒','0','','2025-04-25 18:00:01'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：25191毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 11
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1188)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$38609580.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-04-26 16:00:25'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：368毫秒','0','','2025-04-26 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：1029毫秒','0','','2025-04-26 18:00:01'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：26020毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 11
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1188)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$38609580.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-04-27 16:00:26');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：366毫秒','0','','2025-04-27 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：1025毫秒','0','','2025-04-27 18:00:01'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：9322毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 11
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1198)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$5177ccf2.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-04-28 16:00:09'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：173毫秒','0','','2025-04-28 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：361毫秒','0','','2025-04-28 18:00:00'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：14毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:310)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-04-29 14:16:28'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：8毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-04-29 14:16:29'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：64毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-04-29 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：9416毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 11
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1198)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$5177ccf2.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-04-29 16:00:09'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：35毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:310)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-04-29 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：95毫秒','0','','2025-04-29 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：209毫秒','0','','2025-04-29 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：210毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-04-30 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：11462毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 11
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1198)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$8b123126.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-04-30 16:00:11'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：21毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:310)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-04-30 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：232毫秒','0','','2025-04-30 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：624毫秒','0','','2025-04-30 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：52毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-05-01 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：17927毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 11
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1198)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$8b123126.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-05-01 16:00:17'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：44毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:310)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-05-01 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：176毫秒','0','','2025-05-01 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：680毫秒','0','','2025-05-01 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：303毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-05-02 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：16870毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 11
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1198)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$8b123126.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-05-02 16:00:16'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：23毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:310)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-05-02 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：415毫秒','0','','2025-05-02 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：520毫秒','0','','2025-05-02 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：64毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-05-03 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：16779毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 11
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1198)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$8b123126.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-05-03 16:00:16'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：4毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:310)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-05-03 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：472毫秒','0','','2025-05-03 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：569毫秒','0','','2025-05-03 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：290毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-05-04 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：18132毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 11
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1198)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$8b123126.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-05-04 16:00:18'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：21毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:310)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-05-04 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：376毫秒','0','','2025-05-04 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：727毫秒','0','','2025-05-04 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：29毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-05-05 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：18411毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 11
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1198)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$8b123126.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-05-05 16:00:18'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：36毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:310)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-05-05 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：354毫秒','0','','2025-05-05 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：769毫秒','0','','2025-05-05 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：140毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-05-06 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：11349毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 11
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1205)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$aa8dba78.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-05-06 16:00:11'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：56毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:310)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-05-06 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：429毫秒','0','','2025-05-06 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：875毫秒','0','','2025-05-06 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：100毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-05-07 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：9572毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 11
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1205)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$5177ccf2.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-05-07 16:00:09'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：48毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:310)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-05-07 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：170毫秒','0','','2025-05-07 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：293毫秒','0','','2025-05-07 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：80毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-05-08 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：10470毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 11
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1205)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$4d3b9108.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-05-08 16:00:10'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：39毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:310)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-05-08 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：109毫秒','0','','2025-05-08 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：509毫秒','0','','2025-05-08 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：66毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-05-09 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：9531毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 11
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1205)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$4d3b9108.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-05-09 16:00:09'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：29毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:310)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-05-09 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：106毫秒','0','','2025-05-09 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：249毫秒','0','','2025-05-09 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：7毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-05-10 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：9577毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 11
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1205)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$4d3b9108.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-05-10 16:00:09'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：22毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:310)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-05-10 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：440毫秒','0','','2025-05-10 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：488毫秒','0','','2025-05-10 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：72345744毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-05-11 12:50:38'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：10807毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: org.springframework.dao.QueryTimeoutException: Redis command timed out; nested exception is io.lettuce.core.RedisCommandTimeoutException: Command timed out after 10 second(s)
	at org.springframework.data.redis.connection.lettuce.LettuceExceptionConverter.convert(LettuceExceptionConverter.java:70)
	at org.springframework.data.redis.connection.lettuce.LettuceExceptionConverter.convert(LettuceExceptionConverter.java:41)
	at org.springframework.data.redis.PassThroughExceptionTranslationStrategy.translate(PassThroughExceptionTranslationStrategy.java:44)
	at org.springframework.data.redis.FallbackExceptionTranslationStrategy.translate(FallbackExceptionTranslationStrategy.java:42)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.convertLettuceAccessException(LettuceConnection.java:271)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.await(LettuceConnection.java:1062)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.lambda$doInvoke$4(LettuceConnection.java:919)
	at org.springframework.data.redis.connection.lettuce.LettuceInvoker$Synchronizer.invoke(LettuceInvoker.java:673)
	at ','2025-05-11 12:50:38'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：10809毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: org.springframework.dao.QueryTimeoutException: Redis command timed out; nested exception is io.lettuce.core.RedisCommandTimeoutException: Command timed out after 10 second(s)
	at org.springframework.data.redis.connection.lettuce.LettuceExceptionConverter.convert(LettuceExceptionConverter.java:70)
	at org.springframework.data.redis.connection.lettuce.LettuceExceptionConverter.convert(LettuceExceptionConverter.java:41)
	at org.springframework.data.redis.PassThroughExceptionTranslationStrategy.translate(PassThroughExceptionTranslationStrategy.java:44)
	at org.springframework.data.redis.FallbackExceptionTranslationStrategy.translate(FallbackExceptionTranslationStrategy.java:42)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.convertLettuceAccessException(LettuceConnection.java:271)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.await(LettuceConnection.java:1062)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.lambda$doInvoke$4(LettuceConnection.java:919)
	at org.springframework.data.redis.connection.lettuce.LettuceInvoker$Synchronizer.invoke(LettuceInvoker.java:673)
	at ','2025-05-11 12:50:38');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：95154毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:310)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interc','2025-05-11 12:52:02'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：72499673毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 11
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1205)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$1bd538dd.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-05-11 12:53:06'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：122毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-05-11 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：10621毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 11
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1206)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$16f379f8.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-05-11 16:00:10'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：44毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:312)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-05-11 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：158毫秒','0','','2025-05-11 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：436毫秒','0','','2025-05-11 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：53毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-05-12 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：10548毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 11
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1206)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$7a08ad47.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-05-12 16:00:11'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：22毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:312)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-05-12 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：133毫秒','0','','2025-05-12 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：480毫秒','0','','2025-05-12 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：34毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-05-13 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：4407毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1206)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$aa8dba78.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-05-13 16:00:04'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：32毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:312)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-05-13 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：80毫秒','0','','2025-05-13 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：155毫秒','0','','2025-05-13 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：48毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-05-14 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：4326毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1206)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$be1a8744.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-05-14 16:00:04'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：29毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:312)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-05-14 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：86毫秒','0','','2025-05-14 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：133毫秒','0','','2025-05-14 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：75毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-05-15 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：6981毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1229)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$aa8dba78.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-05-15 16:00:07'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：22毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:314)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-05-15 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：98毫秒','0','','2025-05-15 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：185毫秒','0','','2025-05-15 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：61毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-05-16 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：6503毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1229)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$aa8dba78.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-05-16 16:00:06'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：25毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:314)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-05-16 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：387毫秒','0','','2025-05-16 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：443毫秒','0','','2025-05-16 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：95毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-05-17 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：4736毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$d77dd66f.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-05-17 16:00:04'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：41毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-05-17 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：138毫秒','0','','2025-05-17 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：211毫秒','0','','2025-05-17 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：53毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-05-18 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：5049毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$d77dd66f.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-05-18 16:00:05'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：28毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-05-18 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：118毫秒','0','','2025-05-18 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：211毫秒','0','','2025-05-18 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：14毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-05-19 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：5177毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$d77dd66f.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-05-19 16:00:05'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：18毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-05-19 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：365毫秒','0','','2025-05-19 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：404毫秒','0','','2025-05-19 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：25毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-05-20 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：5381毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$d77dd66f.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-05-20 16:00:05'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：24毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-05-20 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：71毫秒','0','','2025-05-20 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：162毫秒','0','','2025-05-20 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：23毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-05-21 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：5956毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$d77dd66f.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-05-21 16:00:05'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：29毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-05-21 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：51毫秒','0','','2025-05-21 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：445毫秒','0','','2025-05-21 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：30毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-05-22 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：6122毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$d77dd66f.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-05-22 16:00:06'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：22毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-05-22 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：118毫秒','0','','2025-05-22 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：134毫秒','0','','2025-05-22 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：57毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-05-23 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：6761毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$84bbdfe5.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-05-23 16:00:06'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：34毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-05-23 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：107毫秒','0','','2025-05-23 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：346毫秒','0','','2025-05-23 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：47毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-05-24 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：6626毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$84bbdfe5.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-05-24 16:00:06'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：35毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-05-24 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：77毫秒','0','','2025-05-24 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：643毫秒','0','','2025-05-24 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：29毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-05-25 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：6893毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$84bbdfe5.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-05-25 16:00:06'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：22毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-05-25 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：73毫秒','0','','2025-05-25 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：500毫秒','0','','2025-05-25 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：5毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-05-26 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：7192毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$84bbdfe5.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-05-26 16:00:07'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：22毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-05-26 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：114毫秒','0','','2025-05-26 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：553毫秒','0','','2025-05-26 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：29毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-05-27 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：7280毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$84bbdfe5.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-05-27 16:00:07'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：20毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-05-27 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：64毫秒','0','','2025-05-27 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：516毫秒','0','','2025-05-27 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：25毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-05-28 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：7623毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$84bbdfe5.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-05-28 16:00:07'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：18毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-05-28 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：421毫秒','0','','2025-05-28 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：538毫秒','0','','2025-05-28 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：38毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-05-29 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：8038毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$84bbdfe5.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-05-29 16:00:08'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：18毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-05-29 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：423毫秒','0','','2025-05-29 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：836毫秒','0','','2025-05-29 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：38毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-05-30 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：7986毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$84bbdfe5.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-05-30 16:00:07'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：24毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-05-30 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：95毫秒','0','','2025-05-30 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：628毫秒','0','','2025-05-30 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：32毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-05-31 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：7829毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$84bbdfe5.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-05-31 16:00:07'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：328毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-05-31 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：64毫秒','0','','2025-05-31 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：570毫秒','0','','2025-05-31 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：346毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-06-01 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：7957毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$84bbdfe5.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-06-01 16:00:07'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：36毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-06-01 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：69毫秒','0','','2025-06-01 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：514毫秒','0','','2025-06-01 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：21毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-06-02 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：8105毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$84bbdfe5.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-06-02 16:00:08'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：17毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-06-02 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：93毫秒','0','','2025-06-02 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：522毫秒','0','','2025-06-02 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：26毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-06-03 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：8200毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$84bbdfe5.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-06-03 16:00:08'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：23毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-06-03 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：397毫秒','0','','2025-06-03 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：817毫秒','0','','2025-06-03 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：27毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-06-04 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：8405毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$84bbdfe5.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-06-04 16:00:08'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：18毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-06-04 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：424毫秒','0','','2025-06-04 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：841毫秒','0','','2025-06-04 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：26毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-06-05 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：8731毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$84bbdfe5.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-06-05 16:00:08'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：18毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-06-05 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：446毫秒','0','','2025-06-05 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：852毫秒','0','','2025-06-05 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：23毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-06-06 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：8581毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$84bbdfe5.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-06-06 16:00:08'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：19毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-06-06 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：92毫秒','0','','2025-06-06 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：546毫秒','0','','2025-06-06 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：38毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-06-07 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：9138毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$84bbdfe5.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-06-07 16:00:09'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：19毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-06-07 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：402毫秒','0','','2025-06-07 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：823毫秒','0','','2025-06-07 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：42毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-06-08 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：9046毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$84bbdfe5.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-06-08 16:00:09'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：17毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-06-08 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：413毫秒','0','','2025-06-08 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：836毫秒','0','','2025-06-08 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：16毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-06-09 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：4124毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$16f379f8.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-06-09 16:00:04'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：29毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-06-09 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：139毫秒','0','','2025-06-09 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：495毫秒','0','','2025-06-09 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：74毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-06-10 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：5082毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$791e1063.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-06-10 16:00:05'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：41毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-06-10 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：221毫秒','0','','2025-06-10 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：407毫秒','0','','2025-06-10 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：62毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-06-11 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：4479毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$16f379f8.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-06-11 16:00:04'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：28毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-06-11 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：177毫秒','0','','2025-06-11 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：592毫秒','0','','2025-06-11 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：75毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-06-12 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：4314毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$791e1063.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-06-12 16:00:04'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：41毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-06-12 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：225毫秒','0','','2025-06-12 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：607毫秒','0','','2025-06-12 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：58毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-06-13 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：4307毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$791e1063.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-06-13 16:00:04'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：25毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-06-13 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：154毫秒','0','','2025-06-13 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：464毫秒','0','','2025-06-13 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：42毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-06-14 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：4251毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$791e1063.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-06-14 16:00:04'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：38毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-06-14 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：141毫秒','0','','2025-06-14 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：413毫秒','0','','2025-06-14 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：42毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-06-15 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：4464毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$791e1063.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-06-15 16:00:04'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：44毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-06-15 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：82毫秒','0','','2025-06-15 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：270毫秒','0','','2025-06-15 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：35毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-06-16 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：5378毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$791e1063.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-06-16 16:00:05'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：19毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-06-16 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：373毫秒','0','','2025-06-16 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：520毫秒','0','','2025-06-16 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：6毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-06-17 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：5248毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$791e1063.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-06-17 16:00:05'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：30毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-06-17 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：351毫秒','0','','2025-06-17 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：464毫秒','0','','2025-06-17 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：32毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-06-18 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：5340毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$791e1063.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-06-18 16:00:05'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：23毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-06-18 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：381毫秒','0','','2025-06-18 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：521毫秒','0','','2025-06-18 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：39毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-06-19 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：5305毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$791e1063.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-06-19 16:00:05'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：27毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-06-19 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：66毫秒','0','','2025-06-19 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：480毫秒','0','','2025-06-19 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：30毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-06-20 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：4956毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$791e1063.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-06-20 16:00:04'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：21毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-06-20 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：54毫秒','0','','2025-06-20 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：464毫秒','0','','2025-06-20 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：32毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-06-21 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：5304毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$791e1063.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-06-21 16:00:05'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：23毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-06-21 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：333毫秒','0','','2025-06-21 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：483毫秒','0','','2025-06-21 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：30毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-06-22 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：5203毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$791e1063.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-06-22 16:00:05'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：18毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-06-22 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：72毫秒','0','','2025-06-22 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：209毫秒','0','','2025-06-22 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：34毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-06-23 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：5147毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$791e1063.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-06-23 16:00:05'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：22毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-06-23 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：72毫秒','0','','2025-06-23 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：217毫秒','0','','2025-06-23 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：28毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-06-24 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：5339毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$791e1063.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-06-24 16:00:05'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：18毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-06-24 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：81毫秒','0','','2025-06-24 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：220毫秒','0','','2025-06-24 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：36毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-06-25 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：5217毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$791e1063.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-06-25 16:00:05'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：23毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-06-25 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：91毫秒','0','','2025-06-25 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：501毫秒','0','','2025-06-25 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：27毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-06-26 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：5535毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$791e1063.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-06-26 16:00:05'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：23毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-06-26 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：389毫秒','0','','2025-06-26 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：505毫秒','0','','2025-06-26 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：35毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-06-27 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：5268毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$791e1063.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-06-27 16:00:05'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：18毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-06-27 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：63毫秒','0','','2025-06-27 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：528毫秒','0','','2025-06-27 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：32毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-06-28 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：5255毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$791e1063.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-06-28 16:00:05'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：18毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-06-28 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：342毫秒','0','','2025-06-28 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：486毫秒','0','','2025-06-28 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：38毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-06-29 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：5550毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$791e1063.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-06-29 16:00:05'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：20毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-06-29 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：72毫秒','0','','2025-06-29 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：458毫秒','0','','2025-06-29 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：23毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-06-30 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：5262毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$791e1063.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-06-30 16:00:05'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：287毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-06-30 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：57毫秒','0','','2025-06-30 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：550毫秒','0','','2025-06-30 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：34毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-07-01 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：5509毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$791e1063.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-07-01 16:00:05'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：23毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-07-01 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：341毫秒','0','','2025-07-01 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：458毫秒','0','','2025-07-01 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：31毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-07-02 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：5284毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$791e1063.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-07-02 16:00:05'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：19毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-07-02 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：76毫秒','0','','2025-07-02 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：601毫秒','0','','2025-07-02 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：20毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-07-03 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：5293毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$791e1063.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-07-03 16:00:05'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：20毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-07-03 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：63毫秒','0','','2025-07-03 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：502毫秒','0','','2025-07-03 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：26毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-07-04 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：5584毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$791e1063.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-07-04 16:00:05'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：19毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-07-04 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：76毫秒','0','','2025-07-04 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：469毫秒','0','','2025-07-04 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：22毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-07-05 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：5356毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$791e1063.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-07-05 16:00:05'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：19毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-07-05 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：90毫秒','0','','2025-07-05 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：521毫秒','0','','2025-07-05 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：289毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-07-06 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：5552毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$791e1063.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-07-06 16:00:05'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：4毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-07-06 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：388毫秒','0','','2025-07-06 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：526毫秒','0','','2025-07-06 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：25毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-07-07 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：5573毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$791e1063.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-07-07 16:00:05'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：31毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-07-07 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：63毫秒','0','','2025-07-07 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：551毫秒','0','','2025-07-07 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：26毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-07-08 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：6022毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$791e1063.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-07-08 16:00:06'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：18毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-07-08 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：65毫秒','0','','2025-07-08 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：487毫秒','0','','2025-07-08 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：99毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-07-09 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：6416毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$791e1063.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-07-09 16:00:06'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：17毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-07-09 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：470毫秒','0','','2025-07-09 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：611毫秒','0','','2025-07-09 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：26毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-07-10 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：6341毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$791e1063.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-07-10 16:00:06'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：24毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-07-10 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：350毫秒','0','','2025-07-10 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：468毫秒','0','','2025-07-10 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：27毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-07-11 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：6077毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$791e1063.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-07-11 16:00:06'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：311毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-07-11 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：64毫秒','0','','2025-07-11 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：531毫秒','0','','2025-07-11 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：353毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-07-12 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：6403毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$791e1063.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-07-12 16:00:06'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：18毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-07-12 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：121毫秒','0','','2025-07-12 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：557毫秒','0','','2025-07-12 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：17毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-07-13 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：6291毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$791e1063.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-07-13 16:00:06'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：17毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-07-13 17:10:00');
INSERT INTO ruoyi_race.sys_job_log (job_name,job_group,invoke_target,job_message,status,exception_info,create_time) VALUES
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：56毫秒','0','','2025-07-13 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：181毫秒','0','','2025-07-13 18:00:00'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：223毫秒','1','java.lang.reflect.InvocationTargetException
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:77)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:568)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException: Cannot invoke "java.util.Date.getTime()" because the return value of "com.buis.domain.RaceInfo.getJoinEnd()" is null
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-07-14 15:59:59'),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','检查报名中的比赛状态 总共耗时：112毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: java.lang.NullPointerException
	at com.buis.quartz.task.RaceTask.checkRaceStatusJOIN(RaceTask.java:71)
	... 10 more
','2025-07-14 16:00:00'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：5316毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: com.buis.common.exception.ServiceException: 查询失败: nested exception is org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 3
	at com.buis.service.impl.RaceInfoServiceImpl.getHotRace(RaceInfoServiceImpl.java:1230)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy.invokeMethod(CglibAopProxy.java:386)
	at org.springframework.aop.framework.CglibAopProxy.access$000(CglibAopProxy.java:85)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:703)
	at com.buis.service.impl.RaceInfoServiceImpl$$EnhancerBySpringCGLIB$$16f379f8.getHotRace(<generated>)
	at com.buis.quartz.task.RaceTask.warmUpHotRace(RaceTask.java:135)
	... 10 more
','2025-07-14 16:00:05'),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','热门比赛缓存预热 总共耗时：10019毫秒','1','java.lang.reflect.InvocationTargetException
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:77)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:568)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: org.springframework.dao.QueryTimeoutException: Redis command timed out; nested exception is io.lettuce.core.RedisCommandTimeoutException: Command timed out after 10 second(s)
	at org.springframework.data.redis.connection.lettuce.LettuceExceptionConverter.convert(LettuceExceptionConverter.java:70)
	at org.springframework.data.redis.connection.lettuce.LettuceExceptionConverter.convert(LettuceExceptionConverter.java:41)
	at org.springframework.data.redis.PassThroughExceptionTranslationStrategy.translate(PassThroughExceptionTranslationStrategy.java:44)
	at org.springframework.data.redis.FallbackExceptionTranslationStrategy.translate(FallbackExceptionTranslationStrategy.java:42)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.convertLettuceAccessException(LettuceConnection.java:271)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.await(LettuceConnection.java:1062)
	at org.springframework.data.redis.connection.lettuce.LettuceConnection.lambda$doInvoke$4(LettuceConnection.java:919)
	at org.springframework.data.redis.connection.lettuc','2025-07-14 16:00:09'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：274毫秒','1','java.lang.reflect.InvocationTargetException
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:77)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:568)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(','2025-07-14 17:09:59'),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','检查未开始的比赛状态 总共耗时：42毫秒','1','java.lang.reflect.InvocationTargetException
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:61)
	at com.buis.quartz.util.JobInvokeUtil.invokeMethod(JobInvokeUtil.java:33)
	at com.buis.quartz.util.QuartzDisallowConcurrentExecution.doExecute(QuartzDisallowConcurrentExecution.java:19)
	at com.buis.quartz.util.AbstractQuartzJob.execute(AbstractQuartzJob.java:43)
	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)
	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)
Caused by: cn.dev33.satoken.exception.NotWebContextException: 非 web 上下文无法获取 HttpServletRequest
	at cn.dev33.satoken.spring.SpringMVCUtil.getRequest(SpringMVCUtil.java:45)
	at cn.dev33.satoken.spring.SaTokenContextForSpring.getStorage(SaTokenContextForSpring.java:56)
	at cn.dev33.satoken.context.SaHolder.getStorage(SaHolder.java:69)
	at cn.dev33.satoken.stp.StpLogic.isSwitch(StpLogic.java:2536)
	at cn.dev33.satoken.stp.StpLogic.getLoginId(StpLogic.java:948)
	at cn.dev33.satoken.stp.StpUtil.getLoginId(StpUtil.java:350)
	at com.buis.service.impl.RaceInfoServiceImpl.updateRaceInfo(RaceInfoServiceImpl.java:315)
	at com.buis.service.impl.RaceInfoServiceImpl$$FastClassBySpringCGLIB$$98816a65.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:792)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:762)
	at org.springframework.transaction.interceptor.TransactionInterce','2025-07-14 17:10:00'),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','比赛数据缓存预热 总共耗时：170毫秒','0','','2025-07-14 18:00:00'),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','队伍数据缓存预热 总共耗时：622毫秒','0','','2025-07-14 18:00:00');
