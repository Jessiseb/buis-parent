INSERT INTO ruoyi_race.sys_role_dept (role_id,dept_id) VALUES
	 (2,100),
	 (2,101),
	 (2,105);
