INSERT INTO ruoyi_race.sys_dict_type (dict_name,dict_type,status,create_by,create_time,update_by,update_time,remark) VALUES
	 ('用户性别','sys_user_sex','0','admin','2024-10-09 04:32:13','',NULL,'用户性别列表'),
	 ('菜单状态','sys_show_hide','0','admin','2024-10-09 04:32:13','',NULL,'菜单状态列表'),
	 ('系统开关','sys_normal_disable','0','admin','2024-10-09 04:32:13','',NULL,'系统开关列表'),
	 ('任务状态','sys_job_status','0','admin','2024-10-09 04:32:13','',NULL,'任务状态列表'),
	 ('任务分组','sys_job_group','0','admin','2024-10-09 04:32:13','',NULL,'任务分组列表'),
	 ('系统是否','sys_yes_no','0','admin','2024-10-09 04:32:13','',NULL,'系统是否列表'),
	 ('通知类型','sys_notice_type','0','admin','2024-10-09 04:32:13','',NULL,'通知类型列表'),
	 ('通知状态','sys_notice_status','0','admin','2024-10-09 04:32:13','',NULL,'通知状态列表'),
	 ('操作类型','sys_oper_type','0','admin','2024-10-09 04:32:13','',NULL,'操作类型列表'),
	 ('系统状态','sys_common_status','0','admin','2024-10-09 04:32:13','',NULL,'登录状态列表');
INSERT INTO ruoyi_race.sys_dict_type (dict_name,dict_type,status,create_by,create_time,update_by,update_time,remark) VALUES
	 ('互选状态','choose_status','0','admin','2024-10-09 06:10:27','admin','2024-10-09 06:10:33','互选状态（0-待选、1-已选定、2-已拒绝）'),
	 ('计分规则','score_rule','0','admin','2024-10-09 06:12:12','admin','2024-10-09 06:12:20','计分规则（0-取平均，1-去掉最高最低取平均，2-计算权重，3-去掉最高最低计算权重）'),
	 ('比赛类型','race_type','0','admin','2024-10-09 06:13:32','admin','2025-02-27 03:41:41','比赛类型(0-学科竞赛类比赛，1-蓝桥杯，2-第二课堂, 3-大创比赛)'),
	 ('比赛状态','race_status','0','admin','2024-10-09 06:14:36','',NULL,'比赛状态（0-筹备中，1-报名中，2-审核中，3-进行中，4-已结束）'),
	 ('比赛级别','race_level','0','admin','2024-10-09 06:16:28','',NULL,'比赛级别（0-院级，1-校级，2-市级，3-省级，4-国家级）'),
	 ('审核状态','review_status','0','admin','2024-10-09 06:17:57','admin','2025-03-31 13:54:34','审核状态（ 0 待审核 1 审核通过 2 未通过 3 已发布）'),
	 ('职称','teacher_title','0','admin','2024-10-09 06:18:50','admin','2024-10-12 13:42:54','职称(0-助教、1-讲师、2-副教授、3-教授、4-校外指导)'),
	 ('班级','stu_class','0','admin','2024-11-21 09:55:33','',NULL,NULL),
	 ('年级','stu_grade','0','admin','2024-11-21 09:57:18','',NULL,NULL),
	 ('决定者','team_decider','0','admin','2024-12-12 06:23:05','admin','2024-12-12 06:28:36',NULL);
INSERT INTO ruoyi_race.sys_dict_type (dict_name,dict_type,status,create_by,create_time,update_by,update_time,remark) VALUES
	 ('大创类型','innovation_type','0','','2025-02-27 14:34:25','','2025-02-27 14:34:30','大创申报类型(1-创新训练, 2-创业训练)'),
	 ('招募状态','recruit_status','0','admin','2025-03-26 11:52:19','',NULL,'是否发布队伍招募(0-是，1-否）'),
	 ('第二课堂竞赛标签','second_label','0','admin','2025-04-03 01:31:03','admin','2025-04-15 10:31:09',NULL),
	 ('参与方式','particpation_way','0','admin','2025-04-17 09:33:50','',NULL,'参与方式列表'),
	 ('通知类型','notice_type','0','admin','2025-04-20 10:47:18','',NULL,'通知类型（0-组队，1-系统，2-比赛）'),
	 ('获奖等级','award_type','0','admin','2025-05-13 13:06:47','',NULL,NULL);
