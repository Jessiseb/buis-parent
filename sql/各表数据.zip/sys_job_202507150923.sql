INSERT INTO ruoyi_race.sys_job (job_name,job_group,invoke_target,cron_expression,misfire_policy,concurrent,status,create_by,create_time,update_by,update_time,remark) VALUES
	 ('系统默认（无参）','DEFAULT','ryTask.ryNoParams','0/10 * * * * ?','3','1','1','admin','2024-10-09 04:32:21','',NULL,''),
	 ('系统默认（有参）','DEFAULT','ryTask.ryParams(''ry'')','0/15 * * * * ?','3','1','1','admin','2024-10-09 04:32:21','',NULL,''),
	 ('系统默认（多参）','DEFAULT','ryTask.ryMultipleParams(''ry'', true, 2000L, 316.50D, 100)','0/20 * * * * ?','3','1','1','admin','2024-10-09 04:32:21','',NULL,''),
	 ('检查报名中的比赛状态','DEFAULT','RaceTask.checkRaceStatusJOIN','0 0 0 * * ?','1','1','0','admin','2024-12-27 10:16:24','','2025-04-29 14:16:29',''),
	 ('检查未开始的比赛状态','DEFAULT','RaceTask.checkRaceStatusPREPARE','0 10 1 * * ?','1','1','0','admin','2024-12-27 10:18:00','','2025-04-29 14:16:28',''),
	 ('队伍数据缓存预热','DEFAULT','TeamTask.warmUp','0 0 2 * * ?','1','1','0','admin','2025-03-18 10:06:48','','2025-03-29 12:43:47',''),
	 ('比赛数据缓存预热','DEFAULT','RaceTask.warmUp','0 0 2 * * ?','1','1','0','admin','2025-03-26 02:53:23','','2025-03-29 12:43:41',''),
	 ('热门比赛缓存预热','DEFAULT','RaceTask.warmUpHotRace','0 0 0 * * ?','1','1','0','admin','2025-03-26 15:00:39','','2025-03-29 12:43:49','');
