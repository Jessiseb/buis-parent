INSERT INTO ruoyi_race.sys_config (config_name,config_key,config_value,config_type,create_by,create_time,update_by,update_time,remark) VALUES
	 ('主框架页-默认皮肤样式名称','sys.index.skinName','skin-blue','Y','admin','2024-10-09 04:32:18','',NULL,'蓝色 skin-blue、绿色 skin-green、紫色 skin-purple、红色 skin-red、黄色 skin-yellow'),
	 ('用户管理-账号初始密码','sys.user.initPassword','123456','Y','admin','2024-10-09 04:32:18','',NULL,'初始化密码 123456'),
	 ('主框架页-侧边栏主题','sys.index.sideTheme','theme-dark','Y','admin','2024-10-09 04:32:18','',NULL,'深色主题theme-dark，浅色主题theme-light'),
	 ('账号自助-验证码开关','sys.account.captchaEnabled','false','Y','admin','2024-10-09 04:32:18','admin','2024-10-09 06:07:47','是否开启验证码功能（true开启，false关闭）'),
	 ('账号自助-是否开启用户注册功能','sys.account.registerUser','false','Y','admin','2024-10-09 04:32:18','',NULL,'是否开启注册用户功能（true开启，false关闭）'),
	 ('用户登录-黑名单列表','sys.login.blackIPList','','Y','admin','2024-10-09 04:32:18','',NULL,'设置登录IP黑名单限制，多个匹配项以;分隔，支持匹配（*通配、网段）');
