INSERT INTO ruoyi_race.sys_notice (notice_title,notice_type,notice_content,status,create_by,create_time,update_by,update_time,remark) VALUES
	 ('温馨提醒：2018-07-01 若依新版本发布啦','2',0xE696B0E78988E69CACE58685E5AEB9,'0','admin','2024-10-09 04:32:21','',NULL,'管理员'),
	 ('维护通知：2018-07-01 若依系统凌晨维护','1',0xE7BBB4E68AA4E58685E5AEB9,'0','admin','2024-10-09 04:32:21','',NULL,'管理员');
