INSERT INTO ruoyi_race.sys_user_post (user_id,post_id) VALUES
	 (1,1),
	 (101,3),
	 (104,1),
	 (105,1),
	 (106,1),
	 (109,1),
	 (110,1),
	 (111,1),
	 (112,1),
	 (113,1);
INSERT INTO ruoyi_race.sys_user_post (user_id,post_id) VALUES
	 (114,1),
	 (115,1),
	 (116,1),
	 (117,1),
	 (118,1),
	 (119,1),
	 (120,1),
	 (121,1),
	 (122,1),
	 (123,1);
INSERT INTO ruoyi_race.sys_user_post (user_id,post_id) VALUES
	 (124,1),
	 (125,1),
	 (126,1),
	 (127,1),
	 (128,1),
	 (129,1),
	 (130,1),
	 (131,1),
	 (132,1),
	 (133,1);
INSERT INTO ruoyi_race.sys_user_post (user_id,post_id) VALUES
	 (134,1),
	 (135,1),
	 (136,1),
	 (137,1),
	 (138,1),
	 (139,1),
	 (140,1),
	 (141,1),
	 (142,1),
	 (143,1);
INSERT INTO ruoyi_race.sys_user_post (user_id,post_id) VALUES
	 (144,1),
	 (145,1),
	 (146,1),
	 (147,1),
	 (148,1),
	 (149,1),
	 (150,1),
	 (151,1),
	 (152,1),
	 (153,1);
INSERT INTO ruoyi_race.sys_user_post (user_id,post_id) VALUES
	 (154,1),
	 (155,1),
	 (156,1),
	 (157,1),
	 (158,1),
	 (159,1),
	 (160,1),
	 (161,1),
	 (162,1),
	 (163,1);
INSERT INTO ruoyi_race.sys_user_post (user_id,post_id) VALUES
	 (164,1),
	 (165,1),
	 (166,1);
