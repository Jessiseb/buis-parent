INSERT INTO ruoyi_race.sys_post (post_code,post_name,post_sort,status,create_by,create_time,update_by,update_time,remark) VALUES
	 ('ceo','创新服务中心',1,'0','admin','2024-10-09 04:31:55','admin','2024-12-02 11:23:38',''),
	 ('se','项目经理',2,'0','admin','2024-10-09 04:31:55','',NULL,''),
	 ('hr','人力资源',3,'0','admin','2024-10-09 04:31:55','',NULL,''),
	 ('user','普通员工',4,'0','admin','2024-10-09 04:31:55','',NULL,'');
